<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Index</title>
	<!-- css added -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/media.css">
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.min.js"></script>
</head>
<body>
	<!-- Header start -->
	<header class="header">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3 col-xs-5">
					<div class="logo">
						<a href="#"><img src="<?php echo base_url()?>images/logo.png" class="img-responsive"></a>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="top-header-info">
						<p><span>PM AWAS</span> - Customised Services For Housing Ownership</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="top-social-bar">
						<ul>
							<li><a href="#" class="facebook"></a></li>
							<li><a href="#" class="g-plus"></a></li>
							<li><a href="#" class="twitter"></a></li>
							<li><a href="#" class="insta"></a></li>
						</ul>
					</div>
				</div>
			</div>
			<a href="javascript:void(0)"class="mobile-trigger">
				<span></span>
			</a>
		</div>
	</header>
	<!-- Header End -->

	<!-- MENU STRAT -->
	<nav class="menu-wraper">
		<div class="container">
			<ul class="menu">
				<li><a href="#">HOME</a></li>
				<li><a href="#">ABOUT US</a></li>
				<li><a href="#">FAQ</a></li>
				<li><a href="#">SCHEMES</a></li>
				<li><a href="#">CONTACT US</a></li>
			</ul>
		</div>
	</nav>
	<nav class="mobile-menu" id="mobileMenu">
		<ul>
			<li><a href="#">HOME</a></li>
			<li><a href="#">ABOUT US</a></li>
			<li><a href="#">FAQ</a></li>
			<li><a href="#">SCHEMES</a></li>
			<li><a href="#">CONTACT US</a></li>
		</ul>
		<a href="javascript:void(0)" class="hide-trigger">x</a>
	</nav>
	<!-- MENU END -->