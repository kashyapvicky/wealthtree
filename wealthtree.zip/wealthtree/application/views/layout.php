    <!-- include your header view here -->
    <?php $this->load->view('header'); ?>

    


<?php   echo $this->load->view($page); ?>



    <!-- include your footer view here -->
    <?php $this->load->view('footer'); ?>