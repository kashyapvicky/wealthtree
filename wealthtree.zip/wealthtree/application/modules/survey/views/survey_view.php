<section class="construct-quebox">
	<div class="container">
		<div class="wealth-tab">
			<form method="post" action=<?php echo base_url()?>survey/survey_data>
				<ul class="tab-list">
					<li><a href="javascript:void(0)" class="tab tab-ac1 active">Check Your Eliigibility</a></li>
					<li><a href="javascript:void(0)" class="tab tab-ac2">Lorem ipsum dolor sit</a></li>
				</ul>
				<div class="tab-content show" id="tab1">
					<div class="wealth-que-tab" id="que1">
						<h1 class="border-center-hding">Where Do You Want To Construct Your House</h1>
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="slect-row">
									<select name="state_id" onchange="get_city(this.value)" class="formfull-row" id="state">
										<?php
										//print_r($states); die;
										if(!empty($states))
										{
											foreach ($states as $key => $value)
											{

												echo"
												<option value='".$value['id']."'>".$value['name']."</option>
												";
											}
										}

										?>
									</select>
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="slect-row">
									<select name="district_id" class="formfull-row" id="city">
										<option value="" disabled selected="">Choose State First</option>
										
									</select>
								</div>
							</div>
							<div class="col-md-12 col-sm-12">
								<div class="col-md-6 col-sm-6">
								<div class="slect-row">
									<input onchange="movenext()"  id="place" type="text" class="formfull-row" name="place" placeholder="place">
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="slect-row">
									<input onchange="movenext()" type="text" class="formfull-row" name="sub_place" id="sub_place" placeholder="Sub-place">
								</div>
							</div>
							</div>
						</div>
						<a href="javascript:void(0)" id="next" class="next-btn">next</a>
					</div><!-- tab que end -->

					<div class="wealth-que-tab" id="que2">
						<h1 class="border-center-hding">Do You Own A Pakka House</h1>
						<div class="pkka-houseResultbx">
							<div class="row">
								<div class="col-md-5 col-sm-5 col-xs-6 bd-radio">
									<input type="radio" id="test9" name="is_pakka" value="yes" checked>
									<label for="test9">Yes</label>
								</div>
								<div class="col-md-5 col-sm-5 col-xs-6 bd-radio">
									<input  type="radio" id="testa9" name="is_pakka" value="no">
									<label for="testa9">No</label>
								</div>
							</div>
						</div>
						<div class="pakka-house-memberbx" id="pkhouse">
							<div class="bd-radio pk-memberbx">
								<input type="radio"  id="test10" name="pakka" value="in my name">
								<label for="test10">In My Name</label>
							</div>
							<div class="bd-radio pk-memberbx">
								<input type="radio" id="test11" name="pakka" value="in name of my wife">
								<label for="test11">In Name Of My Wife</label>
							</div>
							<div class="bd-radio pk-memberbx">
								<input type="radio" id="test12" name="pakka" value="joint name of my wife and me">
								<label for="test12">Joint Name Of My Wife & Me</label>
							</div>
							<div class="bd-radio pk-memberbx">
								<input type="radio" id="test13" name="pakka" value="in name of any of my minor dependent Children">
								<label for="test13">In Name of Any of My Minor Dependent Children</label>
							</div>
						</div>
						<a href="javascript:void(0)" id="next1" class="next-btn">next</a>
					</div><!-- tab que end -->

					<div class="wealth-que-tab" id="que3">
						<h1 class="border-center-hding">Who Else In Your Family Has Independent Income</h1>
						<div class="faimily-incomebox">
							<label class="container-check">Wife
								<input type="checkbox" class="wcheck" name="family">
								<span class="checkmark"></span>
							</label>
							<div class="wife-salary-row" >
								<input type="text" name="independent_wife" placeholder="Enter Your Income / Salary (Monthly)" class="wsalary">
							</div>

							<label class="container-check">Son
								<input type="checkbox" class="scheck" name="family">
								<span class="checkmark"></span>
								<span class="apnd-icon" id="apnd-icon1"><a href="javascript:void(0)"></a></span>
							</label>
							<div class="son-salary-row">
								<div class="row">
									<div class="col-md-4 col-sm-4 col-xs-12 sagebx">
										<select name="son[age][]" class="sage">
											<option>Select Age</option>
											<option>18</option>
											<option>19</option>
											<option>20</option>
										</select>
									</div>
									<div class="col-md-8 col-sm-8 col-xs-12">
										<input type="text" name="son[salary][]" placeholder="Enter Your Income / Salary (Monthly)" class="wsalary">
									</div>
								</div>
							</div>
							<span id="sonsalaryrow">

							</span>
							<label class="container-check">Daughter
								<input type="checkbox"  class="dcheck" name="family">
								<span class="checkmark"></span>
								<span class="apnd-icon" id="apnd-icon2"><a href="javascript:void(0)"></a></span>
							</label>
							<div class="daughter-salary-row">
								<div class="row">
									<div class="col-md-4 col-sm-4 col-xs-12 sagebx">
										<select name="daughter[age][]" class="sage">
											<option>Select Age</option>
											<option>18</option>
											<option>19</option>
											<option>20</option>
										</select>
									</div>
									<div class="col-md-8 col-sm-8 col-xs-12">
										<input type="text" name="daughter[salary][]" placeholder="Enter Your Income / Salary (Monthly)" class="wsalary">
									</div>
								</div>
							</div>
							<span id="daughtersalaryrow"></span>
						</div>

						<div class="formbtn-box">
							<button class="form-btn">Submit</button>
						</div>
					</form>



					</div>
				</div>
				<div class="tab-content" id="tab2">
					<div class="retirement-box">
						<h1 class="border-center-hding">Where Will You Like To Stay After Retirement</h1>
					</div>
					<div class="after-retbox">
						<div class="row">
							<div class="col-md-12 col-sm-12 form-group bd-radio">
								<input type="radio" id="ret1" name="ret" value="yes" checked="">
								<label for="ret1">At My Native Place</label>
							</div>
							<div class="col-md-12 col-sm-12 form-group bd-radio">
								<input type="radio" id="ret2" name="ret" value="no">
								<label for="ret2">In Metro City</label>
							</div>
							<div class="col-md-12 col-sm-12 form-group bd-radio">
								<input type="radio" id="ret3" name="ret" value="no">
								<label for="ret3">In A Town Near My Native People</label>
							</div>
							<div class="col-md-12 col-sm-12 form-group bd-radio">
								<input type="radio" id="ret4" name="ret" value="no">
								<label for="ret4">Have Not Decided Yet</label>
							</div>
						</div>

						<div class="formbtn-box">
							<button class="form-btn">Submit</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</section>
<script type="text/javascript">

	function get_city(val)
	{
//alert(val);
city_id = val; 

$.ajax({
	type: "POST",
	url: "<?php echo base_url(); ?>" + "survey/get_city",
	dataType: 'json',
	data: {id:city_id},
	success: function(data){
            //alert(data);
            //alert(data);
            //console.log(data);
            $('#city').html(data);
        },
    });
}
</script>
<script>

function movenext()
{
		var s = $('#state').val();
        var d = $('#district').val();
        var p = $('#place').val();
        var sub_place = $('#sub_place').val();

        //alert(s+"--"+d+"---"+p);
        if (s == '' || d == '' || p == '' || sub_place =='') {
            //alert('all field are required');
            return false; 
        }
        else{
        	console.log(sub_place);
        	//console.log(s);
        	// alert('completed');
             $('#que1').hide();
             $('#que2').show();
        }
}
function movepakka()
{
	var value = $('#testa9').val();
	console.log(value);
}	
</script>