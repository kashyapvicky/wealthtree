<?php
  Class Survey_model extends CI_Model
  {
  	public function get_states()
  	{
  		$this->db->select('*');
  		$this->db->where('country_id',101);
  		$query = $this->db->get('states');
  		return $query->result_array();
  	}
  	public function get_city_by_state_id($state_id)
  	{
  		$this->db->select('*');
  		$this->db->where('state_id',$state_id);
  		$query = $this->db->get('cities');
  		return $query->result_array();
  	}
  	public function insert_son($age,$salary,$user_id)
  	{
  		$data = array(
  			'user_id'=>$user_id,
  			'name'=>'son',
  			'age'=>$age,
  			'salary'=>$salary,

  		);
  		$this->db->insert('independent_income',$data);
  	}
  	public function insert_daughter($age,$salary,$user_id)
  	{
  		$data = array(
  			'user_id'=>$user_id,
  			'name'=>'daughter',
  			'age'=>$age,
  			'salary'=>$salary,

  		);
  		$this->db->insert('independent_income',$data);
  		return $this->db->insert_id();
  	}
  	public function insert_basick_survey_data($data)
  	{
  		$this->db->insert('user_basick_survey',$data);
  		return $this->db->insert_id();
  	}
  	public function get_question_and_option()
  	{
  		$this->db->select('qn.name qn_name,qn.id as qn_id,options.op_a,options.op_b,options.op_c,options.op_d');
  		$this->db->join('options','options.qn_id=qn.id','left');
  		$query = $this->db->get('questions as qn');
  		return $query->result_array();
  	}
  	public function op_a_data($data)
  	{
  		$this->db->insert('op_a',$data);
  		return $this->db->insert_id();
  	}
  	public function op_b_data($data)
  	{
  		$this->db->insert('op_b',$data);
  		return $this->db->insert_id();
  	}

  	public function insert_options($option_a_array,$option_b_array,$option_c_array,$option_d_array)
  	{

  		$this->db->trans_start();
  		if(!empty($option_a_array))
  		{
  		$this->db->insert('op_a',$option_a_array);
  		}
  		if(!empty($option_b_array))
  		{
  			$this->db->insert('op_b',$option_b_array);
  		}
  		if(!empty($option_c_array))
  		{
  		$this->db->insert('op_c',$option_c_array);
  		}
  		if(!empty($option_d_array))
  		{
  			$this->db->insert('op_d',$option_d_array);
  		}
  		$this->db->trans_complete();
  		if ($this->db->trans_status() === FALSE)
		{
        	echo"<script>alert('trans_error')</script>";die;
		}
		else
		{
			$this->db->set('is_survey',4);
			$this->db->where('id',$user_id);
			$query = $this->db->update('users');
			if($query)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

  	}
  	public function insert_op_a($data)
  	{
  		$this->db->insert('op_a',$data);
  		return $this->db->insert_id();
  	}
  	public function insert_op_b($data)
  	{
  		$this->db->insert('op_b',$data);
  		return $this->db->insert_id();
  	}
  	public function insert_op_c($data)
  	{
  		$this->db->insert('op_c',$data);
  		return $this->db->insert_id();
  	}
  	public function insert_op_d($data)
  	{
  		$this->db->insert('op_d',$data);
  		return $this->db->insert_id();
  	}
  	public function update_survey_status($user_id)
  	{
		$this->db->set('survey_status',4);
		$this->db->where('id',$user_id);
		$query = $this->db->update('users');
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
  	}

  }


 ?> 
