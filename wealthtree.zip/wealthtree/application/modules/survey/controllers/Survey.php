<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Survey extends MX_Controller {

	function __construct()
    {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('survey_model');
	}

	public function index()
	{
		$states = $this->survey_model->get_states();
		//print_r($states); die;
		$data['states']=$states;
		$data['page']='survey_view';
		_layout($data);
	}
	public function get_city()
	{
		$state_id = $this->input->post('id');
		//echo $country_id;
		//$state_array = $this->website_model->get_state_by_country_id(1);
		//print_r($state_array);
		$city_array = $this->survey_model->get_city_by_state_id($state_id);
		$output ='';
		foreach ($city_array as $key => $value) {

			$output.="<option value='".$value['id']."'>".$value['name']."</option>";
		}
		//print_r($output);
		echo json_encode($output);
	}
	public function survey_data()
	{
		//echo "<pre>";print_r($_POST); die;
		$user_id = $this->session->userdata('user_id');
		//echo $user_id; die;
		$state_id = $this->input->post('state_id');
		$district_id = $this->input->post('district_id');
		$place = $this->input->post('place');
		$sub_place = $this->input->post('sub_place');
		$is_pakka = $this->input->post('is_pakka');
		//$no_pakka = $this->input->post('no_pakka');
		$pakka_name = $this->input->post('pakka');
		//$family = $this->input->post('family');
		$independent_wife = $this->input->post('independent_wife');

		$survey_data = array(

			'user_id'=>$user_id,
			'state_id'=>$state_id,
			'district_id'=>$district_id,
			'place'=>$place,
			'sub_place'=>$sub_place,
			'pakka_house'=>$pakka_name,
			'is_completed'=>2,
		);

		$insert_id = $this->survey_model->insert_basick_survey_data($survey_data);

		if($insert_id)
		{

			$son = $this->input->post('son');
			$daughter = $this->input->post('daughter');


			//print_r($sonage); die;
			if(!empty($son))
			{
				for($i = 0; $i<count($son['age']); $i++)
				{
					$age = $son['age'][$i];
					$salary = $son['salary'][$i];

					// echo $age; 
					// echo"<br>";
					// echo $salary;
					// echo"<br>";
					$this->survey_model->insert_son($age,$salary,$user_id);
				}
			}
			if(!empty($daughter))
			{
				$bool = '';
				for($i = 0; $i<count($daughter['age']); $i++)
				{
					$age = $daughter['age'][$i];
					$salary = $daughter['salary'][$i];
					$bool = $this->survey_model->insert_daughter($age,$salary,$user_id);
				}
				if($bool)
				{
					redirect('survey/second_survey');
				}
			}
		}
		else
		{
			echo"<script>alert('error in insertion')</script>";
		}

	}
	public function second_survey()
	{
		$question_option_array = $this->survey_model->get_question_and_option();
		//echo "<pre>";print_r($question_option_array); die;
		$data['questions_option'] = $question_option_array;
		$data['page']='second_survey';
		_layout($data);
	}
	public function insert_second_survey_data()
	{
		$user_id = $this->session->userdata('user_id');
		//echo"<pre>";print_r($_POST); die;
		$option_a_array = array();
		$option_b_array = array();
		$option_c_array = array();
		$option_d_array = array();
		foreach ($_POST as $key => $value) 
		{

			if($value == 'op_a')
			{
				$option_a_array[] = array(
					'qn_id'=>$key,
					'user_id'=>$user_id

				);


			}
			elseif($value == 'op_b')
			{
				$option_b_array[] = array(
					'qn_id'=>$key,
					'user_id'=>$user_id

				);
			}
			elseif($value == 'op_c')
			{
				$option_c_array[] = array(
					'qn_id'=>$key,
					'user_id'=>$user_id
				);
			}
			else
			{
				
				$option_d_array[] = array(
					'qn_id'=>$key,
					'user_id'=>$user_id
				);
			}
		}
		//echo"<pre>";print_r($option_a_array);die;
		if(!empty($option_a_array))
		{
			foreach ($option_a_array as $key => $value)
			{
				$data = array('qn_id'=>$value['qn_id'],'user_id'=>$user_id);
				$this->survey_model->insert_op_a($data);
				
			}
		}
		if(!empty($option_b_array))
		{
			foreach ($option_b_array as $key => $value)
			{
				$data = array('qn_id'=>$value['qn_id'],'user_id'=>$user_id);
				$this->survey_model->insert_op_b($data);
				
			}
		}
		if(!empty($option_c_array))
		{
			foreach ($option_c_array as $key => $value)
			{
				$data = array('qn_id'=>$value['qn_id'],'user_id'=>$user_id);
				$this->survey_model->insert_op_c($data);
				
			}
		}
		if(!empty($option_d_array))
		{
			foreach ($option_d_array as $key => $value)
			{
				$data = array('qn_id'=>$value['qn_id'],'user_id'=>$user_id);
				$this->survey_model->insert_op_d($data);
				
			}
		}

		$bool = $this->survey_model->update_survey_status($user_id);
		if($bool)
		{
			$this->session->set_flashdata('survey','Your Survey Is Completed Succesfully');
		}
		else
		{
			$this->session->set_flashdata('survey','Something Went Wrong');
		}
		redirect('survey/success_page');
		
	}
	public function success_page()
	{
		$data['msg']='Your Survey Is Completed Successfully';
		$data['page'] = 'success';
		_layout($data);

	}
	
}
