<?php
  Class Home_model extends CI_Model
  {
  	public function check_phone_number($phone_number)
  	{
  		$this->db->select('*');
  		$this->db->where('phone_number',$phone_number);
  		$query=$this->db->get('users');
  		return $query->row_array();
  	}
  	public function check_survey_status($phone_number)
  	{
  		$this->db->select('survey_status,id');
  		$this->db->where('phone_number',$phone_number);
  		$query = $this->db->get('users');
  		return $query->row_array();
  	}
  	public function check_survey_status_with_pan_phone($phone_number,$pan_number)
  	{
  		$this->db->select('survey_status,id');
  		$this->db->where('phone_number',$phone_number);
  		$this->db->or_where('pan_number',$pan_number);
  		$query = $this->db->get('users');
  		return $query->row_array();
  	}
	public function check_pan_phone($phone_number,$pan_number)
	{
		$this->db->select('*');
		$this->db->where('phone_number',$phone_number);
		$this->db->or_where('pan_number',$pan_number);
		$query = $this->db->get('users');
		return $query->row_array();
	}
	public function insert_basic_data($data)
	{
		$this->db->insert('users',$data);
		$insert_id = $this->db->insert_id();
		return  $insert_id;
	}
	public function get_organisations()
	{
		$this->db->select('*');
		$query = $this->db->get('organisations');
		return $query->result_array();
	}
	public function check_basick_survey($user_id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$user_id);
		$query = $this->db->get('user_basick_survey');
		return $query->row_array();
	}

  }


 ?> 
