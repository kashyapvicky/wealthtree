


	<section class="successful-wraper text-center">
		<p><?php if(!empty($msg))
		{
			echo $msg;
		}
		else
		{
			echo"Message is not set";
		}
		?></p>
	</section>
	
