<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MX_Controller {

	function __construct()
    {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('home_model');
	}

	public function index()
	{
		$data['page']='home_view';
		_layout($data);
	}
	public function send_otp_to_mobile()
	{
		//echo 1;
		//echo"hello"; die;
		
		// if(!empty($this->input->post('phone_number')))
		// {

			//echo"<script>alert('test')</script>";
			$this->session->unset_userdata('otp');
			$phone_number = $this->input->post('phone_number');
			//echo $phone_number;
			 $this->session->set_userdata('otp',1234);
			 $this->session->set_userdata('phone_number',$phone_number);
			echo $phone_number;
			//redirect('home/after_validation');
		// }
		// else
		// {
		// 	$this->session->set_flashdata('phone_empty','Please Enter your Mobile Number');
		// }

		// redirect(base_url());
	}
	public function validate_otp()
	{
		$otp = $this->session->userdata('otp');
		$first_digit = $this->input->post('digit1');
		$second_digit = $this->input->post('digit2');
		$third_digit = $this->input->post('digit3');
		$fourth_digit = $this->input->post('digit4');
		$otp_entered = "".$first_digit.""+"".$second_digit.""+"".$third_digit.""+"".$fourth_digit."";
		// echo $otp_entered;
		// echo"<br>";
		// echo $otp;
		// die;
		if($otp == $otp_entered)
		{
			redirect('home/after_validation');
		}
		else
		{
			$this->session->set_flashdata('Invalid_otp','YOU ENTERED A INVALID OTP');
		}
		redirect(base_url());
	}
	public function after_validation()
	{
		//echo"there"; die;
		$phone_number = $this->session->userdata('phone_number');
		$row = $this->home_model->check_phone_number($phone_number);
		if($row)
		{
			$row = $this->home_model->check_survey_status($phone_number);
			$survey_status = $row['survey_status'];
			if((int)$survey_status >= 0 && (int)$survey_status <  4)
			{
				$basick_survey_row = $this->home_model->check_basick_survey($row['id']);
				$basick_complete_status = $basick_survey_row['is_completed'];

				if((int)$basick_complete_status == 2)
				{
					$this->session->set_userdata('user_id',$row['id']);
					redirect('survey/second_survey');
				}
				else
				{ 

					$org_array = $this->home_model->get_organisations();
					$data['organisations'] = $org_array;
					$data['page'] = 'organisation';
					_layout($data);
				}
			}
			else
			{
				$data['msg'] = 'Your Survey Is Already Completed';
				$data['page'] = 'success';
				_layout($data);
			}
		}
		else
		{
			//echo"hello";die;
			$org_array = $this->home_model->get_organisations();
			$data['organisations'] = $org_array;
			$data['page'] = 'organisation';
			_layout($data);
		}

	}
	public function check_pan_phone_existence()
	{
		$phone_number = $this->input->post('phone_no');
		$pan_number = $this->input->post('pan_no');

		$row = $this->home_model->check_pan_phone($phone_number,$pan_number);
		if($row)
		{
			$row = $this->home_model->check_survey_status_with_pan_phone($phone_number,$pan_number);
			$survey_status = $row['survey_status'];
			if((int)$survey_status >= 0 && (int)$survey_status <  4)
			{
				$basick_survey_row = $this->home_model->check_basick_survey($row['id']);
				$basick_complete_status = $basick_survey_row['is_completed'];

				if((int)$basick_complete_status == 2)
				{
					$this->session->set_userdata('user_id',$row['id']);
					redirect('survey/second_survey');
				}
				else
				{ 

					$org_array = $this->home_model->get_organisations();
					$data['organisations'] = $org_array;
					$data['page'] = 'organisation';
					_layout($data);
				}
			}
			else
			{
				$data['msg'] = 'Your Survey Is Already Completed';
				$data['page'] = 'success';
				_layout($data);
			}
		}
		else
		{
			redirect('home/insert_basick_detail');
		}

	}
	public function insert_basick_detail()
	{
		$this->form_validation->set_rules('first_name', 'First Name', 'required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'required');
		$this->form_validation->set_rules('pan_number', 'Pan Number', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('working', 'Working', 'required');
		$this->form_validation->set_rules('income', 'Income', 'required');
		$this->form_validation->set_rules('org', 'Organisation', 'required');
		$this->form_validation->set_rules('psu', 'PSU', 'required');
		if ($this->form_validation->run() == TRUE)
		{ 
			$phone_number = $this->session->userdata('phone_number');
			$first_name = $this->input->post('first_name');
			$last_name = $this->input->post('last_name');
			$email = $this->input->post('email');
			$pan_number = $this->input->post('pan_number');
			$dob = $this->input->post('dob');
			$gender = $this->input->post('gender');
			$working = $this->input->post('working');
			$income = $this->input->post('income');
			//$income = $this->input->post('income');
			$org = $this->input->post('org');
			$psu = $this->input->post('psu');
			$data = array(
			'first_name'=>$first_name,
			'last_name'=>$last_name,
			'email'=>$email,
			'dob'=>$dob,
			'phone_number'=>$phone_number,
			'gender'=>$gender,
			'working'=>$working,
			'income'=>$income,
			'org'=>$org,
			'psu'=>$psu,
			'pan_number'=>$pan_number,
			'user_type'=>'website'
			);
			$insert_id = $this->home_model->insert_basic_data($data);
			if($insert_id)
			{
				
				$this->session->set_userdata('user_id',$insert_id);
				redirect('survey');
			}
			else{
				$this->sesssion->set_flashdata('basick_error','Error In Insertion');
			}

		} 
		
		$data['page']='basick_detail';
		_layout($data);
	}
}
