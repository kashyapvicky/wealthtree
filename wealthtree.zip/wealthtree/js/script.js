$(document).ready(function(){
   // alert('helllo');
	$('.mobile-trigger').click(function(){
		$('body').addClass('show-nav');
	});

	$('.hide-trigger').click(function(){
		$('body').removeClass('show-nav');
	});
	$('.subsidybtn').click(function(){
		$('body').addClass('show-popup');
	});

	$('.hide-phNopopup').click(function(){
		$('body').removeClass('show-popup');
	});
	$('.hide-otppopup').click(function(){
		$('.otpPopup-wraper').hide();
	});

	// $('.tab').click(function(event){
	// 	event.preventDefault();
	// 	$('.tab').removeClass('active');
	// 	$('.tab-content').removeClass('show');
	// 	$(this).addClass('active');
	// 	$($(this).attr('href')).addClass('show');
	// });

	$('#next').click(function(){
		var s = $('#state').val();
		var d = $('#district').val();
		var p = $('#place').val();
        //alert(s+"--"+d+"---"+p);
		if (s == '' || d == '' || p == '') {
            alert('all field are required');
            return false; 
        }
        else{
        	$('#que1').hide();
        	$('#que2').show();
        }
	});

$("#test9").click(function(){
    //alert('hello');
	if ($('input[id=test9]:checked').val()){
        $("#pkhouse").show();
    }
});

$("#testa9").click(function(){
	if ($('input[id=testa9]:checked').val()){
        $("#pkhouse").hide();
    }
});

$("#next1").click(function(){
	if($('input[id=test9]:checked').val()){
        //alert('checked');
	if (!$('input[name=is_pakka]:checked').val()) {
        alert("required");
    }
}

 if($('input[id=test9]:checked').val()){
    	if ($('input[name=is_pakka]:checked').val()) {
    	$('#que2').hide();
        $('#que3').show();
    }
	}
    if($('input[id=testa9]:checked').val()){
    	$('#que2').hide();
        $('#que3').show();
    }

});

// show hide checkbox
    $(".wcheck").on("click",function() {
    	$(".wife-salary-row").toggle(this.checked);
  });
    $(".scheck").on("click",function() {
    	$(".son-salary-row").toggle(this.checked);
    	$("#apnd-icon1").toggle(this.checked);

  });

    $(".dcheck").on("click",function() {
        $(".daughter-salary-row").toggle(this.checked);
    	$("#apnd-icon2").toggle(this.checked);

  });

    var i = 0;
	$("#apnd-icon1 a").click(function(){
    	//alert('hlo');
    	i++;
   
 
      $('#sonsalaryrow').append('<div id="row'+i+'" class="apnd-row"><div class="son-salary-row"><div class="row"><div class="col-md-4 sagebx"><select name="son[age][]" class="sage"><option>Select Agee</option><option>18</option><option>19</option><option>20</option></select></div><div class="col-md-8"><input type="text" name=son[salary][] placeholder="Enter Your Income / Salary (Monthly)" class="wsalary"></div></div></div><a id='+i+' class="custom_cut"></a></div>')
    });
    $(document).on('click','.custom_cut', function(){
       var button_id = $(this).attr("id");
       $("#row"+button_id+"").remove();
    });

    $("#apnd-icon2 a").click(function(){
    	i++;
 
      $('#daughtersalaryrow').append('<div id="roww'+i+'" class="apnd-row"><div class="daughter-salary-row"><div class="row"><div class="col-md-4 sagebx"><select name="daughter[age][]" class="sage"><option>Select Age</option><option>21</option><option>22</option><option>23</option></select></div><div class="col-md-8"><input type="text" name="daughter[salary][]" placeholder="Enter Your Income / Salary (Monthly)" class="wsalary"></div></div></div><a id='+i+' class="custom_cut1"></a></div>')
    });
    $(document).on('click','.custom_cut1', function(){
       var button_id1 = $(this).attr("id");
       $("#roww"+button_id1+"").remove();
    });


    $("#next3").click(function(){
	 var fields = $("input[name='family']").serializeArray(); 
    if (fields.length === 0) 
    { 
        alert('nothing selected'); 
        // cancel submit
        return false;
    } 
    else 
    { 
    $('#tab1').removeClass('show');
    $($(this).attr('href')).addClass('show');
    $('.tab-ac1').removeClass('active');
    $('.tab-ac2').addClass('active');
    }
});
    //login
$('#login-form').click(function(){
	var logNo = $('#login-no').val();
	if(logNo == ""){
		alert("please enter your Mobile Number");
		return false;
	}
	else{
		$('.phNopopup-wraper').hide();
		$('.otpPopup-wraper').css("top","0");
		return false;
	}
		});
$('#verify-btn').click(function(){
	window.open("construct-house.html");
});
});


// Onload
$("#pkhouse").show();
